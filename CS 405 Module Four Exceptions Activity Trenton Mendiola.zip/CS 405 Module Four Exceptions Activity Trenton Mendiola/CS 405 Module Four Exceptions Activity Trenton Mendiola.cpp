// CS 405 Module Four Exceptions Activity Trenton Mendiola.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//custom exception class code comes from Geeks for Geeks 
//resource https://www.geeksforgeeks.org/how-to-throw-custom-exception-in-cpp/

//defines custom exception
class customException : public std::exception {
private:
    std::string message;

public:
    // Constructor accepts a const char* that is used to set
    // the exception message
    customException(const char* msg)
        : message(msg)
    {
    }

    // Override the what() method to return our message
    const char* what() const throw()
    {
        return message.c_str();
    }
};



bool do_even_more_custom_application_logic()
{
    //Throw invalid_argument exception 
    throw std::invalid_argument("Invalid Argument");
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    //try do_even_more_custom_application_logic
    try {
        //if successful output success message
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //catch std::exception
    catch (std::exception& e) {
        //output message indicating exception was caught and what exception using e.what
        std::cout << "Caught Exception: " << e.what() << std::endl;        
    }
    //output leaving message
    std::cout << "Leaving Custom Application Logic." << std::endl;
    //throw custom exception
    throw customException("CustomException");
    
}

float divide(float num, float den)
{
    //If denominator is = to 0
    if (den == 0) {
        //throw runtime_error indicating you are attempting to divide by 0
        throw std::runtime_error("Error: attempting to divide by zero!");
    }
    return (num / den);
}

void do_division() noexcept
{
   
    float numerator = 10.0f;
    float denominator = 0;
    //define results variable, initialize with 0
    auto result = 0;
    try {
        result = divide(numerator, denominator);
    }
    catch (std::runtime_error& e) {
        //output the numerator, denominator, and result (result will be zero as we are trying to divide by 0 exception will be thrown in divide method and result will not be changed from its initial value)
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
        //output error message indicating exception was caught and why
        std::cout << "Exception Caught! " << e.what() << std::endl;
        
    }
    
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //try our methods
    try {
        do_division();
        do_custom_application_logic();
    }
    //catch exceptions

    //catch the custom exception
    catch (customException& e) {
        //display message indicating the custom exception was caught 
        std::cout << "Custom Exception Caught" << std::endl;
    }
    //catch the std::exception
    catch (std::exception& e) {
        //display message indicating the std::exception was caught
        std::cout << "std::exception Caught" << std::endl;
    }
    //catch any uncaught exceptions
    catch (...) {
        //display message indicating an unknown exception was caught
        std::cout << "unknown exception caught" << std::endl;
    }
}

//references
//Custom exception logic 
// https://www.geeksforgeeks.org/how-to-throw-custom-exception-in-cpp/
// 
// 
//Divide by zero exception logic
// https://www.geeksforgeeks.org/handling-the-divide-by-zero-exception-in-c/
//
//General Exception logic
// https://www.geeksforgeeks.org/exception-handling-c/

