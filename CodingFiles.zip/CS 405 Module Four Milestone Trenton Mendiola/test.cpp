// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
   // FAIL();
//}

//Testo to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    //assert the collection is empty
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //add one entry to the collection
    add_entries(1);

    //assert the collection is not empty
    ASSERT_FALSE(collection->empty());

    //since we added one entry the collection should have a size of 1
    ASSERT_EQ(collection->size(), 1);
}

//Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //add 5 entries to the collection
    add_entries(5);

   //since we added five entries the collection should have a size of 5
   ASSERT_EQ(collection->size(), 5);

}

//test to verify max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, verifyMaxSize)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    ////assert that collections max size is greater than or equal to size for 0 entries
    ASSERT_TRUE(collection->size() <= collection->max_size());
    
   //add 1 entry making 1 entry in total in the collection
    add_entries(1);
    //assert that collections max size is greater than or equal to size for 1 entry
    ASSERT_TRUE(collection->size() <= collection->max_size());
    //add 4 more entries making 5 entries total in the collection
    add_entries(4);
    //assert that collections max size is greater than or equal to size for 5 entries
    ASSERT_TRUE(collection->size() <= collection->max_size());
    //add 5 more entries making 10 entries in total in the collection
    add_entries(5);
    //assert that collections max size is greater than or equal to size for 10 entries
    ASSERT_TRUE(collection->size() <= collection->max_size());
}

//test to verify capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, verifyCapacitySize)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //test that capacity is greater than or equal to size for 1 entries
    ASSERT_EQ(collection->size(), 0);

    //test max size for 0 entries
    ASSERT_TRUE(collection->size() <= collection->capacity());

    //add 1 entry making 1 entry in total in the collection
    add_entries(1);
    //test that capacity is greater than or equal to size for 1 entry
    ASSERT_TRUE(collection->size() <= collection->capacity());
    //add 4 more entries making 5 entries total in the collection
    add_entries(4);
    //test that capacity is greater than or equal to size for 5 entries
    ASSERT_TRUE(collection->size() <= collection->capacity());
    //add 5 more entries making 10 entries in total in the collection
    add_entries(5);
    //test that capacity is greater than or equal to size for 10 entries
    ASSERT_TRUE(collection->size() <= collection->capacity());
}

//Test to verify resizing increases the collection
TEST_F(CollectionTest, verifyResizeIncreasesCollection)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //increase the size of the collection by 5 using resize
    collection->resize(5);
    //verify the collection size is now 5, larger than before
    ASSERT_EQ(collection->size(), 5);
}
//Test to verify resizing decreases the collection
TEST_F(CollectionTest, verifyResizingDecreasesCollection)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());
    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);
    //add entries to the collection
    add_entries(10);
    //verify the collection size is 10
    ASSERT_EQ(collection->size(), 10);
    //decrease the size of the collection to 5 using resize
    collection->resize(5);
    //verify the collection is now the size of 5, less than before
    ASSERT_EQ(collection->size(), 5);
  
}
//Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, verifyResizingDecreasesCollectionToZero)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());
    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);
    //add entries to the collection
    add_entries(10);
    //verify the collection size is 10
    ASSERT_EQ(collection->size(), 10);
    //decrease the size of the collection to 0 using resize
    collection->resize(0);
    //verify the collection is now the size of 0, less than before
    ASSERT_EQ(collection->size(), 0);
}
//Test to verify clear erases the collection
TEST_F(CollectionTest, clearErasesCollection)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //add 5 entries to the collection
    add_entries(5);

    //since we added five entries the collection should have a size of 5
    ASSERT_EQ(collection->size(), 5);

    //use clear
    collection->clear();

    //assert true the collection is empty again
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

}
//Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, eraseErasesTheCollection)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //add 5 entries to the collection
    add_entries(5);

    //since we added five entries the collection should have a size of 5
    ASSERT_EQ(collection->size(), 5);

    //use erase (begin, end)
    collection->erase(collection->begin(), collection->end());

    //assert true the collection is empty again
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);
}
//Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, verifyReserveIncreasesCapacityButNotSize)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //assert the capacity is currently 0
    ASSERT_EQ(collection->capacity(), 0);

    //use reserve to increase capacity to 10
    collection->reserve(10);

    //assert the capacity was increased to 10
    ASSERT_EQ(collection->capacity(), 10);

    //assert the size of the collection is unchanged, staying at 0
    ASSERT_EQ(collection->size(), 0);

}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// negative test
TEST_F(CollectionTest, verifyOutOfRangeIsThrownUsingAtOutOfBounds)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    EXPECT_THROW(collection->at(5), std::out_of_range);

}

//negative test
//Test to verify that using resize with a value greater than the max size will result in a length error
TEST_F(CollectionTest, verifyLengthErrorOccursWhenResizingPastMaxSize)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //define value that will be 1 more than the max size of the collection
    size_t moreThanMax = collection->max_size() +1;
    //check to ensure length error is thrown when resizing using the moreThanMax value
    EXPECT_THROW(collection->resize(moreThanMax) , std::length_error);
}

//positive test
//Test to verify adding values to the collection multiple times will result in expected size value
TEST_F(CollectionTest, verifyMultipleAddEntries)
{
    //assert the collection is empty 
    ASSERT_TRUE(collection->empty());

    //if it is empty the collection will be 0
    ASSERT_EQ(collection->size(), 0);

    //add 1 entry
    add_entries(1);
    //verify the size of the collection is 1 entry
    ASSERT_EQ(collection->size(), 1);
    //add another 4 entries to make total entries 5
    add_entries(4);
    //verify the size of the collection is 5 entries
    ASSERT_EQ(collection->size(), 5);
    //add another 5 entries to make total entries 10
    add_entries(5);
    //verify the size of the collection is 10 entries
    ASSERT_EQ(collection->size(), 10);
}

//References
// used for resize and erase code
//https://cplusplus.com/reference/vector/vector/erase/
//https://cplusplus.com/reference/vector/vector/resize/
// used throughout the code for different methods, will be expanded upon in the summary
//Google. (2025). Gemini 2.0 [Large language model]. https://g.co/gemini/share/335b8f9c79bf 