// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>




/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
  // get lengths now instead of calling the function every time.
  // this would have most likely been inlined by the compiler, but design for performance.
  const auto key_length = key.length();
  const auto source_length = source.length();

  // assert that our input data is good
  assert(key_length > 0);
  assert(source_length > 0);

  std::string output = source;

  // loop through the source string char by char
  for (size_t i = 0; i < source_length; ++i)
  { 
    // transform each character based on an xor of the key modded constrained to key length using a mod
      output[i] = output[i] ^ key[i % key_length];
  }

  // our output length must equal our source length
  assert(output.length() == source_length);


  // return the transformed string
  return output;
}


std::string read_file(const std::string& filename)
{
  //variable to store file contents
  std::string file_text;

  //define file name as path to open file
  std::string filePath = filename;
  //open file using ifstream
  std::ifstream file(filePath);

  //check that the file is open
  if (!file.is_open()) {
      //if the file is not open display error message
      std::cout << "Failed to open file!" << std::endl;
      //end program
      return "";
  }
  //define string variable to hold each line
  std::string line;
  //while getline is running in the file
  while (getline(file, line)) {
      //add each line to the file_text string
      file_text += line + std::string(1, '\n');
      
  }
  //close the file
  file.close();
  //return the file text
  return file_text;
}

std::string get_student_name(const std::string& string_data)
{
  std::string student_name;

  // find the first newline
  size_t pos = string_data.find('\n');
  // did we find a newline
  if (pos != std::string::npos)
  { // we did, so copy that substring as the student name
    student_name = string_data.substr(0, pos);
  }

  return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
  //  file format
  std::ofstream outputFile(filename);
  //  Line 1: student name
  outputFile << student_name << std::endl;
  //  Line 2: timestamp (yyyy-mm-dd)
  
 //references
  //CO Pilot gen AI June 8 2025
  //w3 schools
  //get timestamp
  time_t timestamp;
  time(&timestamp);
  //create buffer
  char buffer[11];
  //create structure for time
  struct tm timeInfo;
  //use local time s with timeInfo and timestamp
  localtime_s(&timeInfo, &timestamp);
  //use strftime to format time into year month day
  strftime(buffer, sizeof(buffer), "%Y-%m-%d", &timeInfo);
  //put results in file
  outputFile << buffer << std::endl;

  //  Line 3: key used
  outputFile << key << std::endl;
  //  Line 4+: data
  outputFile << data << std::endl;
}

int main()
{
  std::cout << "Encyption Decryption Test!" << std::endl;

  // input file format
  // Line 1: <students name>
  // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
  // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
  //  Fire in the hole bowsprit Jack Tar gally holystone sloop grog heave to grapple Sea Legs. Gally hearties case shot crimp spirits pillage galleon chase guns skysail yo-ho-ho. Jury mast coxswain measured fer yer chains man-of-war Privateer yardarm aft handsomely Jolly Roger mutiny.
  //  Hulk coffer doubloon Shiver me timbers long clothes skysail Nelsons folly reef sails Jack Tar Davy Jones' Locker. Splice the main brace ye fathom me bilge water walk the plank bowsprit gun Blimey wench. Parrel Gold Road clap of thunder Shiver me timbers hempen halter yardarm grapple wench bilged on her anchor American Main.
  //  Brigantine coxswain interloper jolly boat heave down cutlass crow's nest wherry dance the hempen jig spirits. Interloper Sea Legs plunder shrouds knave sloop run a shot across the bow Jack Ketch mutiny barkadeer. Heave to gun matey Arr draft jolly boat marooned Cat o'nine tails topsail Blimey.

  const std::string file_name = "inputdatafile.txt";
  const std::string encrypted_file_name = "encrypteddatafile.txt";
  const std::string decrypted_file_name = "decrytpteddatafile.txt";
  const std::string source_string = read_file(file_name);
  const std::string key = "password";

  // get the student name from the data file
  const std::string student_name = get_student_name(source_string);

  // encrypt sourceString with key
  const std::string encrypted_string = encrypt_decrypt(source_string, key);

  // save encrypted_string to file
  save_data_file(encrypted_file_name, student_name, key, encrypted_string);

  // decrypt encryptedString with key
  const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

  // save decrypted_string to file
  save_data_file(decrypted_file_name, student_name, key, decrypted_string);

  std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

  // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


//references
//
//Encryption 
// https://www.geeksforgeeks.org/xor-cipher/
// https://www.geeksforgeeks.org/xor-encryption-shifting-plaintext/
// 
// Using key length 
// https://crypto.stackexchange.com/questions/24332/key-length-requirement-in-a-simple-xor-implementation
// 
//Read file
//https://www.geeksforgeeks.org/how-to-read-file-into-string-in-cpp/
// https://stackoverflow.com/questions/18802398/how-do-i-retain-a-files-formatting-when-passing-its-data-into-a-string
//Write file
// https://cplusplus.com/forum/beginner/205850/
//
//Date and Time
// https://www.w3schools.com/cpp/cpp_date.asp
//CoPilot, "How to structure current date in "yyyy-mm-dd", "I need to utilize localtime_s", Microsoft, June 8th 2025